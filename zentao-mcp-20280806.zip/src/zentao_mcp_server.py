import anyio
import click
import pymysql
import json
from typing import List, Dict, Any
import mcp.types as types
from mcp.server.lowlevel import Server


class ZentaoDatabase:
    """禅道数据库连接管理类"""
    
    def __init__(self, host: str = '192.168.2.84', port: int = 3306, 
                 user: str = 'dev', password: str = '123456', 
                 database: str = 'zentao', charset: str = 'utf8'):
        self.connection_params = {
            'host': host,
            'port': port,
            'user': user,
            'passwd': password,
            'db': database,
            'charset': charset
        }
        self.connection = None
    
    def connect(self):
        """连接数据库"""
        try:
            self.connection = pymysql.connect(**self.connection_params)
            return True
        except Exception as e:
            print(f"数据库连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开数据库连接"""
        if self.connection:
            self.connection.close()
            self.connection = None
    
    def get_products(self) -> List[Dict[str, Any]]:
        """获取产品列表"""
        if not self.connection:
            if not self.connect():
                return []
        
        try:
            with self.connection.cursor() as cursor:
                sql = """
                SELECT id, name, code, PO, QD, createdBy, createdDate 
                FROM zt_product 
                WHERE deleted = '0'
                ORDER BY id
                """
                cursor.execute(sql)
                results = cursor.fetchall()
                
                products = []
                for row in results:
                    product = {
                        'id': row[0],  # 产品唯一编号
                        'name': row[1],  # 产品名
                        'code': row[2],  # 产品缩写名
                        'PO': row[3],  # 负责的产品经理
                        'QD': row[4],  # 负责的测试主管
                        'createdBy': row[5],  # 此记录的创建人
                        'createdDate': str(row[6]) if row[6] else None  # 此记录的创建日期
                    }
                    products.append(product)
                
                return products
        except Exception as e:
            print(f"查询产品列表失败: {e}")
            return []


# 全局数据库实例
db = ZentaoDatabase()


async def get_zentao_products() -> list[types.ContentBlock]:
    """获取禅道产品列表"""
    products = db.get_products()
    
    if not products:
        return [types.TextContent(
            type="text", 
            text="无法获取产品列表，请检查数据库连接"
        )]
    
    # 格式化产品信息
    product_text = "禅道产品列表:\n\n"
    for product in products:
        product_text += f"产品ID: {product['id']}\n"
        product_text += f"产品名: {product['name']}\n"
        product_text += f"产品缩写: {product['code']}\n"
        product_text += f"产品经理: {product['PO']}\n"
        product_text += f"测试主管: {product['QD']}\n"
        product_text += f"创建人: {product['createdBy']}\n"
        product_text += f"创建日期: {product['createdDate']}\n"
        product_text += "-" * 40 + "\n"
    
    # 同时返回JSON格式的数据
    json_data = json.dumps(products, ensure_ascii=False, indent=2)
    
    return [
        types.TextContent(type="text", text=product_text),
        types.TextContent(type="text", text=f"JSON格式数据:\n{json_data}")
    ]


@click.command()
@click.option("--port", default=8000, help="Port to listen on for SSE")
@click.option(
    "--transport",
    type=click.Choice(["stdio", "sse"]),
    default="sse",
    help="Transport type",
)
def main(port: int, transport: str) -> int:
    """主函数，启动MCP服务器"""
    app = Server("zentao-mcp-server")

    @app.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[types.ContentBlock]:
        """处理工具调用"""
        if name == "list_products":
            return await get_zentao_products()
        else:
            raise ValueError(f"Unknown tool: {name}")

    @app.list_tools()
    async def list_tools() -> list[types.Tool]:
        """列出可用的工具"""
        return [
            types.Tool(
                name="list_products",
                title="禅道产品列表",
                description="获取禅道系统中所有产品的列表，包括产品ID、名称、负责人等信息",
                inputSchema={
                    "type": "object",
                    "properties": {},
                    "required": []
                },
            )
        ]    # 启动时连接数据库
    if not db.connect():
        print("警告: 数据库连接失败，服务器仍会启动，但功能可能受限")

    if transport == "sse":
        from mcp.server.sse import SseServerTransport
        from starlette.applications import Starlette
        from starlette.responses import Response, PlainTextResponse
        from starlette.routing import Mount, Route

        sse = SseServerTransport("/messages/")

        async def handle_sse(request):
            async with sse.connect_sse(
                request.scope, request.receive, request._send
            ) as streams:
                await app.run(
                    streams[0], streams[1], app.create_initialization_options()
                )
            return Response()

        async def handle_root(request):
            """处理根路径请求"""
            return PlainTextResponse("Zentao MCP Server is running. Use SSE endpoint for connections.")

        starlette_app = Starlette(
            debug=True,
            routes=[
                Route("/", endpoint=handle_sse, methods=["GET"]),  # 根路径作为主要SSE端点
                Route("/sse", endpoint=handle_sse, methods=["GET"]),  # 备用SSE端点
                Route("/status", endpoint=handle_root, methods=["GET"]),  # 状态检查端点
                Mount("/messages/", app=sse.handle_post_message),
            ],
        )

        import uvicorn
        print(f"启动禅道MCP服务器 (SSE模式) 在端口 {port}")
        print(f"主要SSE端点: http://127.0.0.1:{port}/")
        print(f"备用SSE端点: http://127.0.0.1:{port}/sse")
        print(f"状态检查端点: http://127.0.0.1:{port}/status")
        uvicorn.run(starlette_app, host="127.0.0.1", port=port)
    else:
        from mcp.server.stdio import stdio_server

        async def arun():
            async with stdio_server() as streams:
                await app.run(
                    streams[0], streams[1], app.create_initialization_options()
                )

        print("启动禅道MCP服务器 (STDIO模式)")
        anyio.run(arun)

    # 服务器关闭时断开数据库连接
    db.disconnect()
    return 0


if __name__ == "__main__":
    import sys
    sys.argv = ['zentao_mcp_server.py', '--port', '8000', '--transport', 'sse']    
    main()
