# zentao-mcp 项目开发与规划
## 整体规划
### 实现AI的一个MCP server，参考.\examples\servers\simple-tool\mcp_simple_tool\server.py。完成sse协议的mcp server.
### 用python编码，代码生成在./src, 测试代码生成在./test

### 阶段一
**目标**： 连接mysql数据库，代码如下：
pymysql.connect(host='192.168.2.84', port=3306,user='dev', passwd='123456', db='zentao', charset='utf8')

### 阶段二
**目标**： 从表zt_product获取字段,提供mcp枚举产品的接口。
#### 数据表：zt_product
#### 字段及自然名映射：
#### id: 产品唯一编号
#### name: 产品名
#### code: 产品缩写名
#### PO: 负责的产品经理
#### QD: 负责的测试主管
#### createdBy: 此记录的创建人
#### createdDate: 此记录的创建日期
#### 返回数据符合MCP要求

### 阶段三
